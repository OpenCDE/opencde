#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include "Xfwf/XmATerm.h"

#include <pty.h>
#include <ctype.h>
#include <string.h>
#include <assert.h>
#include <stdarg.h>

#include <sys/types.h>


int system_noshell(const char *cmd, ...);

int syserr(char *s);

static String fallback_resources[] = {
	"AnsiTermT*borderWidth: 0",			/* For all widgets */
	"AnsiTermT*shadowThickness: 2",		/* 3D border */
	"AnsiTermT*font: -*-courier-medium-r-*--*-140-*-*-*-*-iso8859-1",
	"AnsiTermT.ansiterm.background: black",
	"AnsiTermT.ansiterm.foreground: green",
	NULL,
};

static void out_cb(client_data, fid, id)
    XtPointer client_data;
    int *fid;
    XtInputId *id;
{
    Widget term = (Widget) client_data;
    char buf[BUFSIZ];
    int nbytes;

    if ((nbytes = read(*fid, buf, sizeof(buf))) == -1) syserr("read");
    XfwfAnsiWrite(term, buf, nbytes);
    fprintf(stderr, " [%d]", nbytes);
}


static void key_cb(w, client_data, call_data)
    Widget w;
    XtPointer client_data, call_data;
{
    int *fd = (int *) client_data;
    char *data = (char *) call_data;

    if (write(*fd, data, 1) == -1) syserr("write");
}




void main(argc, argv)
    int argc;
    char *argv[];
{
    XtAppContext app_context;
    Widget toplevel, ansiterm;

	 toplevel = XtVaAppInitialize(&app_context, "AnsiTermT", NULL, 0, &argc,
			 argv, fallback_resources, NULL);

	 ansiterm = XtVaCreateManagedWidget("ansiterm", xmAnsiTermWidgetClass,
			 toplevel, NULL);

	 /************************************/
	 int fd_master=posix_openpt(O_RDWR|O_NOCTTY);
	 int ppid=getpid();   // Process ID of parent
	 int cpid=-1;      // Get child PID later
	 const char *pts;  // slave pseudoterm

	 int s;
	 char c;

	 assert( fd_master >= 0 );  // Did master terminal open?

	 fprintf(stderr, "[P] Opened fd_master = %d\n", fd_master);

	 assert( unlockpt(fd_master) >= 0 ); // Unlock PTY

	 fprintf(stderr, "[P] Unlocked fd_master\n");

	 assert( (pts=ptsname(fd_master)) != NULL ); // Get slave name

	 fprintf(stderr, "[P] Name of slave: %s\n", pts);

	 // Create a child process to use the slave pty
	 assert( (cpid=fork()) >= 0);

	 if(cpid == 0)  // Child code
   {
      int fd_slave=-1;  // Slave PTY
      // Save real stderr so fprintf writes to it instead of pty
      int STDERR=dup(STDERR_FILENO);
      FILE *stderr=fdopen(STDERR, "w");
      setvbuf(stderr, NULL, _IONBF, 0);

      assert( close(fd_master) >= 0 ); // Ditch master PTY

      assert( (fd_slave=open(pts,O_RDWR)) >= 0); // Open slave PTY

      fprintf(stderr, "\t[C] Opened slave %s\n", pts);

      // This will dup fd over stdin,out,err then close fd
      // This function needs compilation with -lutil
      assert( login_tty(fd_slave) >= 0 );

      assert( system_noshell("/bin/stty", "-echo", NULL) == 0);

      assert( execl("/bin/csh", "/bin/zsh", NULL) >= 0);

      exit(1);
   }

	fprintf(stderr, "[P] Created child pid=%d\n", cpid);

   // Parent code
  // assert( read(fd_master, &c, 1) == 1 );
  // assert( c == '+' );  // Child should have written |

  // fprintf(stderr, "[P] Read first char from child\n");

   // The \004 in the middle is not read by cat.
   // Instead, it makes cat do two reads of three bytes
   // instead of one read of 6 bytes.
 // assert( write(fd_master, "abc\004abc", 7) == 7);

//   fprintf(stderr, "[P] Wrote data to child\n");

   // This hangs if I don't write two EOF chars.
  // assert( write(fd_master, "\004\004", 2) == 2 );

 //  fprintf(stderr, "[P] Wrote EOF\n");

 //  while(read(fd_master, &c, 1) == 1)  // Read bytes until EOF
//   {
//      if(c<0x20)  fprintf(stderr, "[P] Read ^%c\n", c+'@');
//      else     fprintf(stderr, "[P] Read byte '%c'\n", c);
//   }

/****/
	XtAppAddInput(app_context, fd_master, (XtPointer) XtInputReadMask,
			out_cb, ansiterm);
	XtAddCallback(ansiterm, XtNkeyCallback, key_cb, &fd_master);
/****/
	 /************************************/

	 XtRealizeWidget(toplevel);
	 XtAppMainLoop(app_context);
}


#define MAX_ARGS 16

int system_noshell(const char *cmd, ...)
{
   const char *args[MAX_ARGS]={cmd};
   int n=0, status;
   va_list ap;

   // Assemble varargs into the args array
   va_start(ap, cmd);
      do
         args[++n]=va_arg(ap, void *);
      while((args[n]) && (n<(MAX_ARGS-2)));
   va_end(ap);

   args[++n]=NULL;   // Terminate argument list

   n=fork();
   if(n < 0)
      return(-1);
   else if(n == 0)
   {
      execvp(cmd, args);
      exit(255);
   }

   assert( waitpid(n, &status, 0) == n);
   return(WEXITSTATUS(status));
}

syserr(s)
	char *s;
{
	fprintf(stderr, "panic: %s\n", s);
}
