/* cvtStringToColor -- convert a string to closest color with XCC */
Boolean cvtStringToColor(
#if NeedFunctionPrototypes
    Display *dpy,
    XrmValue *args,
    Cardinal *num_args,
    XrmValue *from,
    XrmValue *to,
    XtPointer *converter_data
#endif
    );
