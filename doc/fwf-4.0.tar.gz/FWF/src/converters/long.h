#ifndef _long_h_
#define	_long_h_

Boolean XfwfCvtLongToString(
#if NeedFunctionPrototypes
    Display *display,
    XrmValuePtr args,
    Cardinal *num_args,
    XrmValuePtr from,
    XrmValuePtr to,
    XtPointer *converter_data
#endif
);

#endif
