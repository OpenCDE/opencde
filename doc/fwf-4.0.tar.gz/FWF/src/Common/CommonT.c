#include <stdio.h>
#include <stdlib.h>

main()
{
    (void) printf("Sorry, cannot test Common this way.\n");
    (void) printf("Test one of the subclasses instead, e.g., Button.\n");
    exit(0);
}
