#ifndef NO_XPM
#include <X11/xpm.h>
#include "wheel0.pm"
#include "wheel1.pm"
#include "wheel2.pm"
#include "wheel3.pm"
#include "wheel0h.pm"
#include "wheel1h.pm"
#include "wheel2h.pm"
#include "wheel3h.pm"
#else
#include "wheel0.bm"
#include "wheel1.bm"
#include "wheel2.bm"
#include "wheel3.bm"
#include "wheel0h.bm"
#include "wheel1h.bm"
#include "wheel2h.bm"
#include "wheel3h.bm"
#endif
