/* XPM */
static char *wheel3h[] = {
/* width height ncolors chars_per_pixel */
"64 15 10 1",
/* colors */
"` c #000000",
"a c #AFAFAF",
"b c #7D7D7D",
"c c #C8C8C8",
"d c #969696",
"e c #646464",
"f c #FFFFFF",
"g c #FFFF00",
"h c #323232",
"i c #E1E1E1",
/* pixels */
"``hhhhhh`hhhhhhhhhhhh`hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh``",
"``hhhhhg`ifeiiiciifeiccccaacaf`aaaaddadddi`dbbbei`eeeeeeghhhhh``",
"``hhhhgg`ifeiiiiicfeccccacaaaf`aaadadddddi`dbbbbi`eeeeeegghhhh``",
"``hhhggg`ifeiiiciifeiccccaacaf`aaaaddadddi`dbbbei`eeeeeeggghhh``",
"``hhgggg`ifeiiiiicfeccccacaaaf`aaadadddddi`dbbbbi`eeeeeegggghh``",
"``hggggg`ifeiiiciifeiccccaacaf`aaaaddadddi`dbbbei`eeeeeegggggh``",
"``gggggg`ifeiiiiicfeccccacaaaf`aaadadddddi`dbbbbi`eeeeeegggggg``",
"`ggggggg`ifeiiiciifeiccccaacaf`aaaaddadddi`dbbbei`eeeeeeggggggg`",
"``gggggg`ifeiiiiicfeccccacaaaf`aaadadddddi`dbbbbi`eeeeeegggggg``",
"``hggggg`ifeiiiciifeiccccaacaf`aaaaddadddi`dbbbei`eeeeeegggggh``",
"``hhgggg`ifeiiiiicfeccccacaaaf`aaadadddddi`dbbbbi`eeeeeegggghh``",
"``hhhggg`ifeiiiciifeiccccaacaf`aaaaddadddi`dbbbei`eeeeeeggghhh``",
"``hhhhgg`ifeiiiiicfeccccacaaaf`aaadadddddi`dbbbbi`eeeeeegghhhh``",
"``hhhhhg`ifeiiiciifeiccccaacaf`aaaaddadddi`dbbbei`eeeeeeghhhhh``",
"``hhhhhhhhhhhhhhhhhhhhhh````hhh`hhhh`hhhh`hhhh`hhhh`hhhhhhhhhh``"
};
