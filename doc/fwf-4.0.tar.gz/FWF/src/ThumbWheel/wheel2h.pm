/* XPM */
static char *wheel2h[] = {
/* width height ncolors chars_per_pixel */
"64 15 11 1",
/* colors */
"` c #000000",
"a c #AFAFAF",
"b c #7D7D7D",
"c c #4B4B4B",
"d c #C8C8C8",
"e c #969696",
"f c #646464",
"g c #FFFFFF",
"h c #FFFF00",
"i c #323232",
"j c #E1E1E1",
/* pixels */
"``iiiiii`iiiiiiiiiiii`iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii``",
"``iiiiih`gfjjjjdgfddjddddagcaaaaaaaeeag`eeebbbbj`fffffa`hiiiii``",
"``iiiihh`gfjjjjjgfjdddddadgcaaaaaaeaeeg`eebebbbj`fffffa`hhiiii``",
"``iiihhh`gfjjjjdgfddjddddagcaaaaaaaeeag`eeebbbbj`fffffa`hhhiii``",
"``iihhhh`gfjjjjjgfjdddddadgcaaaaaaeaeeg`eebebbbj`fffffa`hhhhii``",
"``ihhhhh`gfjjjjdgfddjddddagcaaaaaaaeeag`eeebbbbj`fffffa`hhhhhi``",
"``hhhhhh`gfjjjjjgfjdddddadgcaaaaaaeaeeg`eebebbbj`fffffa`hhhhhh``",
"`hhhhhhh`gfjjjjdgfddjddddagcaaaaaaaeeag`eeebbbbj`fffffa`hhhhhhh`",
"``hhhhhh`gfjjjjjgfjdddddadgcaaaaaaeaeeg`eebebbbj`fffffa`hhhhhh``",
"``ihhhhh`gfjjjjdgfddjddddagcaaaaaaaeeag`eeebbbbj`fffffa`hhhhhi``",
"``iihhhh`gfjjjjjgfjdddddadgcaaaaaaeaeeg`eebebbbj`fffffa`hhhhii``",
"``iiihhh`gfjjjjdgfddjddddagcaaaaaaaeeag`eeebbbbj`fffffa`hhhiii``",
"``iiiihh`gfjjjjjgfjdddddadgcaaaaaaeaeeg`eebebbbj`fffffa`hhiiii``",
"``iiiiih`gfjjjjdgfddjddddagcaaaaaaaeeag`eeebbbbj`fffffa`hiiiii``",
"``iiiiiiiiiiiiiiiiiiiiii````iii`iiii`iiii`iiii`iiii`iiiiiiiiii``"
};
