/* XPM */
static char *wheel1h[] = {
/* width height ncolors chars_per_pixel */
"64 15 11 1",
/* colors */
"` c #000000",
"a c #AFAFAF",
"b c #7D7D7D",
"c c #4B4B4B",
"d c #C8C8C8",
"e c #969696",
"f c #646464",
"g c #FFFFFF",
"h c #FFFF00",
"i c #323232",
"j c #E1E1E1",
/* pixels */
"``iiiiii`iiiiiiiiiiii`iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii``",
"``iiiiih`jjjjjgfjjddjddgcaadaaaaaaeg`aeeeeebbj`fffffd`ffhiiiii``",
"``iiiihh`jjjjjgfjdjddddgcdaaaaaaaaag`eeeeebebj`bffffd`ffhhiiii``",
"``iiihhh`jjjjjgfjjddjddgcaadaaaaaaeg`aeeeeebbj`fffffd`ffhhhiii``",
"``iihhhh`jjjjjgfjdjddddgcdaaaaaaaaag`eeeeebebj`bffffd`ffhhhhii``",
"``ihhhhh`jjjjjgfjjddjddgcaadaaaaaaeg`aeeeeebbj`fffffd`ffhhhhhi``",
"``hhhhhh`jjjjjgfjdjddddgcdaaaaaaaaag`eeeeebebj`bffffd`ffhhhhhh``",
"`hhhhhhh`jjjjjgfjjddjddgcaadaaaaaaeg`aeeeeebbj`fffffd`ffhhhhhhh`",
"``hhhhhh`jjjjjgfjdjddddgcdaaaaaaaaag`eeeeebebj`bffffd`ffhhhhhh``",
"``ihhhhh`jjjjjgfjjddjddgcaadaaaaaaeg`aeeeeebbj`fffffd`ffhhhhhi``",
"``iihhhh`jjjjjgfjdjddddgcdaaaaaaaaag`eeeeebebj`bffffd`ffhhhhii``",
"``iiihhh`jjjjjgfjjddjddgcaadaaaaaaeg`aeeeeebbj`fffffd`ffhhhiii``",
"``iiiihh`jjjjjgfjdjddddgcdaaaaaaaaag`eeeeebebj`bffffd`ffhhiiii``",
"``iiiiih`jjjjjgfjjddjddgcaadaaaaaaeg`aeeeeebbj`fffffd`ffhiiiii``",
"``iiiiiiiiiiiiiiiiiiiiii````iiiiiiii`iiii`iiii`iiii`iiiiiiiiii``"
};
