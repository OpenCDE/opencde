/* XPM */
static char *wheel0h[] = {
/* width height ncolors chars_per_pixel */
"64 15 11 1",
/* colors */
"` c #000000",
"a c #AFAFAF",
"b c #7D7D7D",
"c c #4B4B4B",
"d c #C8C8C8",
"e c #969696",
"f c #646464",
"g c #FFFFFF",
"h c #FFFF00",
"i c #323232",
"j c #E1E1E1",
/* pixels */
"``iiiiii`iiiiiiiiiiii`iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii``",
"``iiiiih`jjjgfjdjjddjgcddaadaaaag`aeeaeeeebj`bbfffd`ffffhiiiii``",
"``iiiihh`jjjgfjjjdjddgcdadaaaaaag`eaeeeeeebj`bbbffd`ffffhhiiii``",
"``iiihhh`jjjgfjdjjddjgcddaadaaaag`aeeaeeeeej`bbfffd`ffffhhhiii``",
"``iihhhh`jjjgfjjjdjddgcdadaaaaaag`eaeeeeeebj`bbbffd`ffffhhhhii``",
"``ihhhhh`jjjgfjdjjddjgcddaadaaaag`aeeaeeeeej`bbfffd`ffffhhhhhi``",
"``hhhhhh`jjjgfjjjdjddgcdadaaaaaag`eaeeeeeebj`bbbffd`ffffhhhhhh``",
"`hhhhhhh`jjjgfjdjjddjgcddaadaaaag`aeeaeeeeej`bbfffd`ffffhhhhhhh`",
"``hhhhhh`jjjgfjjjdjddgcdadaaaaaag`eaeeeeeebj`bbbffd`ffffhhhhhh``",
"``ihhhhh`jjjgfjdjjddjgcddaadaaaag`aeeaeeeeej`bbfffd`ffffhhhhhi``",
"``iihhhh`jjjgfjjjdjddgcdadaaaaaag`eaeeeeeebj`bbbffd`ffffhhhhii``",
"``iiihhh`jjjgfjdjjddjgcddaadaaaag`aeeaeeeeej`bbfffd`ffffhhhiii``",
"``iiiihh`jjjgfjjjdjddgcdadaaaaaag`eaeeeeeebj`bbbffd`ffffhhiiii``",
"``iiiiih`jjjgfjdjjddjgcddaadaaaag`aeeaeeeeej`bbfffd`ffffhiiiii``",
"``iiiiiiiiiiiiiiiiiiiiii````iii`iiii`iiii`iiii`iiii`iiiiiiiiii``"
};
